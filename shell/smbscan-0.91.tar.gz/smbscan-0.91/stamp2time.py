import time, sys
print time.strftime( '%Y-%m-%d %T', time.localtime(float(sys.argv[1])))
