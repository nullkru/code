#ifndef BOT_H
#define BOT_H

extern int  bot_term;

#endif /* #ifdef BOT_H */
